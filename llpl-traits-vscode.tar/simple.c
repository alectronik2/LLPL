#include <stdint.h>
#include <stddef.h>
#include "runtime.h"

typedef struct Counter Counter;

Counter* Counter_new(int64_t initial);
void Counter_destroy(void* ptr);
void Counter_increment(Counter* self);
int64_t Counter_get_value(Counter* self);

// Module: /home/nix/Claude/LLPL/test/simple.llpl
struct Counter {
    RefCount ref_count;
    int64_t value;
};

Counter* Counter_new(int64_t initial) {
    Counter* self = (Counter*)rc_alloc(sizeof(Counter));
    if (!self) return NULL;
    rc_init(&self->ref_count);

    self->value = initial;
    return self;
}

void Counter_destroy(void* ptr) {
    Counter* self = (Counter*)ptr;
}

void Counter_increment(Counter* self) {
    self->value = (self->value + 1);
}

int64_t Counter_get_value(Counter* self) {
    return self->value;
}


int64_t factorial(int64_t n) {
    if ((n <= 1)) {
        return 1;
    }
    return (n * factorial((n - 1)));
}

void test_loops() {
    int64_t sum = 0;
    int64_t i = 0;
    while ((i < 10)) {
        sum = (sum + i);
        i = (i + 1);
    }
    {
        int64_t j = 0;
        while ((j < 5)) {
            sum = (sum + j);
            j = (j + 1);
        }
    }
}

void test_defer() {
    Counter* counter = Counter_new(0);
    Counter_increment(counter);
    Counter_increment(counter);
    int64_t result = Counter_get_value(counter);
}

int64_t main() {
    Counter* counter = Counter_new(10);
    Counter_increment(counter);
    Counter_increment(counter);
    int64_t value = Counter_get_value(counter);
    int64_t fact = factorial(5);
    test_loops();
    test_defer();
    return 0;
}

